module SingeletonPattern {
}