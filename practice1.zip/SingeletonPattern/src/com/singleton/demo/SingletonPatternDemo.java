package com.singleton.demo;

public class SingletonPatternDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SingletonObject object2=SingletonObject.getInstance();
		object2.showMessage();

	}

}
